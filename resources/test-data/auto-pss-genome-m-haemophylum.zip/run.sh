#!/bin/bash

# Edit the PROJECT_DIR variable
AUTO_PSS_GENOME_PD=/path/to/auto-pss-genome-project

# Adjust the COMPI_NUM_TASKS to an appropiate value
COMPI_NUM_TASKS=8

docker run --rm -v /tmp:/tmp -v /var/run/docker.sock:/var/run/docker.sock -v ${AUTO_PSS_GENOME_PD}:/working_dir --rm pegi3s/auto-pss-genome /compi run -o --logs /working_dir/logs --num-tasks ${COMPI_NUM_TASKS} -- --host_working_dir ${AUTO_PSS_GENOME_PD} --compi_num_tasks ${COMPI_NUM_TASKS}
